import urllib.request
import urllib.error

target_url = "http://testphp.vulnweb.com/listproducts.php?cat="
payload = "'"

print("-" * 50)
print(f"[+] Testing URL for SQL Injection: {target_url}")
print("-" * 50)

test_url = target_url + payload

try:
    response = urllib.request.urlopen(test_url)
    html_content = response.read().decode('utf-8')
    
    sql_errors = [
        "you have an error in your sql syntax",
        "mysql_fetch_array",
        "unclosed quotation mark after the character string",
        "oracle error",
        "postgreSQL query failed"
    ]
    
    vulnerable = False
    
    for error in sql_errors:
        if error in html_content.lower():
            print(f"[!] WARNING: Database error detected!")
            print(f"--> Found signature: '{error}'")
            print(f"--> Target is likely VULNERABLE to SQL Injection!")
            vulnerable = True
            break
            
    if not vulnerable:
        print("[ ] No common SQL errors detected. Target seems secure.")

except urllib.error.URLError as e:
    print(f"[-] Could not connect to target: {e}")

print("-" * 50)
