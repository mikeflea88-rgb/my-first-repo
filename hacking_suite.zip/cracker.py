import hashlib
import sys

# 1. This is the MD5 hash of the password we want to crack.
# (Can you guess which password from our list this is?)
target_hash = "5ebe2294ecd0e0f08eab7690d2a6ee69" 

print("-" * 50)
print(f"[+] Target MD5 Hash: {target_hash}")
print("[+] Reading wordlist: passwords.txt...")
print("-" * 50)

# 2. Open our password list and read the lines
try:
    with open("passwords.txt", "r") as file:
        for line in file:
            # Strip out any hidden newline spaces at the end of each word
            password = line.strip()
            
            # Convert the password string into bytes, then generate the MD5 hash
            guess_hash = hashlib.md5(password.encode('utf-8')).hexdigest()
            
            # Check if our guess hash matches the target hash
            if guess_hash == target_hash:
                print(f"[!] PASSWORD CRACKED SUCCESSFULLY!")
                print(f"--> Hash: {target_hash}")
                print(f"--> Password: {password}")
                print("-" * 50)
                sys.exit(0)
            else:
                print(f"[ ] Trying: {password:12} | Hash: {guess_hash}")

    print("[-] Finished. Password not found in the wordlist.")
    print("-" * 50)

except FileNotFoundError:
    print("[!] Error: 'passwords.txt' file not found. Create it first!")
