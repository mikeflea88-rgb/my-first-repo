import socket
import sys

# We'll target scanme.nmap.org on port 22 (SSH usually sends a banner instantly)
target_host = "scanme.nmap.org"
target_port = 22

print("-" * 50)
print(f"[+] Attempting to grab banner from {target_host}:{target_port}...")
print("-" * 50)

try:
    # 1. Create the socket
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(3.0)  # Wait up to 3 seconds for a response
    
    # 2. Connect to the target
    s.connect((target_host, target_port))
    
    # 3. Receive the banner (up to 1024 bytes of data)
    # decode('utf-8') turns the raw bytes into readable text
    banner = s.recv(1024).decode('utf-8').strip()
    
    print(f"[!] SUCCESS! Banner retrieved:")
    print(f"--> {banner}")

except socket.timeout:
    print("[-] Error: Connection timed out (no banner sent).")
except ConnectionRefusedError:
    print("[-] Error: Connection refused (is the port actually open?).")
except Exception as e:
    print(f"[-] An error occurred: {e}")
finally:
    s.close()

print("-" * 50)
