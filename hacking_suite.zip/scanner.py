import socket
import sys
from datetime import datetime

# 1. Get Target Input from the User
target_input = input("Enter target host or IP (e.g., scanme.nmap.org): ")

try:
    target_ip = socket.gethostbyname(target_input)
except socket.gaierror:
    print("\n[!] Error: Hostname could not be resolved.")
    sys.exit()

# 2. Get Port Range from the User
try:
    start_port = int(input("Enter starting port (e.g., 1): "))
    end_port = int(input("Enter ending port (e.g., 100): "))
except ValueError:
    print("\n[!] Error: Please enter valid numbers for ports.")
    sys.exit()

print("-" * 50)
print(f"Scanning target: {target_input} ({target_ip})")
print(f"Scanning ports: {start_port} to {end_port}")
print(f"Time started: {str(datetime.now())}")
print("-" * 50)

# 3. The Scan Loop (using a range)
# We add + 1 to end_port because range() in Python is exclusive of the last number
for port in range(start_port, end_port + 1):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(0.5) # Fast 0.5s timeout to speed up the range scan
    
    result = s.connect_ex((target_ip, port))
    
    if result == 0:
        print(f"[*] Port {port:5}: OPEN")
    
    s.close()

print("-" * 50)
print("Scan complete!")
