import urllib.request
import sys

mac_address = input("Enter MAC address to look up (e.g., 00:11:22:33:44:55): ").strip()

if not mac_address:
    print("[!] MAC address cannot be empty.")
    sys.exit(1)

print("-" * 50)
print(f"[+] Looking up manufacturer for MAC: {mac_address}")
print("-" * 50)

url = f"https://api.macvendors.com/{mac_address}"

try:
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    with urllib.request.urlopen(req) as response:
        manufacturer = response.read().decode('utf-8')
        print(f"[!] FOUND: This device is manufactured by: {manufacturer}")
except urllib.error.HTTPError as e:
    if e.code == 404:
        print("[-] Error: MAC address vendor not found.")
    else:
        print(f"[-] HTTP Error: {e.code}")
except Exception as e:
    print(f"[-] Connection Error: {e}")
print("-" * 50)
