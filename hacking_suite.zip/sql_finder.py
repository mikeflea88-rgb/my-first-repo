import urllib.request
import urllib.error

# We will test a website specifically designed for legal security testing
target_url = "http://testphp.vulnweb.com/listproducts.php?cat="

# The payload: A single quote designed to break weak SQL queries
payload = "'"

print("-" * 50)
print(f"[+] Testing URL for SQL Injection: {target_url}")
print("-" * 50)

# Combine the URL with our payload (it becomes ...listproducts.php?cat=')
test_url = target_url + payload

try:
    # Send a request to the web page
    response = urllib.request.urlopen(test_url)
    html_content = response.read().decode('utf-8')
    
    # Common SQL database error messages to look for in the website's HTML code
    sql_errors = [
        "you have an error in your sql syntax",
        "mysql_fetch_array",
        "unclosed quotation mark after the character string",
        "oracle error",
        "postgreSQL query failed"
    ]
    
    vulnerable = False
    
    # Check if any of these errors appeared on the page
    for error in sql_errors:
        if error in html_content.lower():
            print(f"[!] WARNING: Database error detected!")
            print(f"--> Found signature: '{error}'")
            print(f"--> Target is likely VULNERABLE to SQL Injection!")
            vulnerable = True
            break
            
    if not vulnerable:
        print("[ ] No common SQL errors detected. Target seems secure.")

except urllib.error.URLError as e:
    print(f"[-] Could not connect to target: {e}")

print("-" * 50)
