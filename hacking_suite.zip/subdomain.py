import socket
import sys

target_domain = "google.com"

# A list of common subdomains to check
subdomains_to_test = ["www", "mail", "ftp", "admin", "blog", "dev", "test", "api"]

print("-" * 50)
print(f"[+] Scanning subdomains for: {target_domain}")
print("-" * 50)

for sub in subdomains_to_test:
    # Combine the subdomain with the target (e.g., admin.google.com)
    full_url = f"{sub}.{target_domain}"
    
    try:
        # Try to resolve the subdomain to an IP address
        ip_address = socket.gethostbyname(full_url)
        print(f"[+] FOUND: {full_url:25} --> IP: {ip_address}")
    except socket.gaierror:
        # If the domain doesn't exist, socket throws an error. We just skip it.
        pass

print("-" * 50)
print("Scan complete!")
