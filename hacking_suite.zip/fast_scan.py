import socket
import threading
from queue import Queue

target = "scanme.nmap.org"
target_ip = socket.gethostbyname(target)

queue = Queue()
open_ports = []

for port in range(1, 501):
    queue.put(port)

def scan_port():
    while not queue.empty():
        port = queue.get()
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(1.0)
        result = s.connect_ex((target_ip, port))
        if result == 0:
            print(f"[!] Port {port} is OPEN!")
            open_ports.append(port)
        s.close()
        queue.task_done()

print("-" * 50)
print(f"[+] Starting ultra-fast multi-threaded scan on {target}...")
print("-" * 50)

thread_list = []
for i in range(100):
    t = threading.Thread(target=scan_port)
    thread_list.append(t)
    t.start()

for t in thread_list:
    t.join()

print("-" * 50)
print(f"Scan complete! Open ports: {sorted(open_ports)}")
print("-" * 50)
